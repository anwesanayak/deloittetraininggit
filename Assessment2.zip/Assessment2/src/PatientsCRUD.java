import java.sql.Connection;
import java.sql.Driver;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

import javax.swing.DefaultButtonModel;

import oracle.jdbc.driver.OracleDriver;

 class patientsTable {
	
	private String username = "hr";
	private String password = "hr";
	private String url = "jdbc:oracle:thin:@192.168.1.42:1522:xe";
	Driver driver = null;
	Connection conn = null;
	
	public patientsTable() {
		try {
          driver = new OracleDriver();
          DriverManager.registerDriver(driver);
          conn=DriverManager.getConnection(url,username,password);
	}
		catch(Exception e) {
			
		}

}
	void addRecord(int pid, String pname, String pemail, Date regdDate) {
		String q = "INSERT INTO PatientsTable VALUES(?,?,?,?)";
		try {
		PreparedStatement p = conn.prepareStatement(q);
		p.setInt(1, pid);
		p.setString(2,pname);
		p.setString(3,pemail);
		p.setDate(4, (java.sql.Date) regdDate);
		int res = p.executeUpdate();
		if(res > 0)
		System.out.println("Inserted!");
		else
		System.out.println("Not inserted");
		}
		catch(Exception e) {System.out.println("Not inserted");}
		}
	
	
	void addRecordPes(int pesid, Date pesdate, int pid, String medname) {
		String q = "INSERT INTO PescriptionsTable VALUES(?,?,?,?)";
		try {
		PreparedStatement p = conn.prepareStatement(q);
		p.setInt(1, pesid);
		p.setDate(2, (java.sql.Date) pesdate);
		p.setInt(3,pid);
		p.setString(4, medname);
		int res = p.executeUpdate();
		if(res > 0)
		System.out.println("Inserted!");
		else
		System.out.println("Not inserted");
		}
		catch(Exception e) {System.out.println("Not inserted");}
		}
	
	void deleteRecord(int b) {
		String q = "DELETE FROM PatientsTable WHERE PID = ?";
		try {
		PreparedStatement p = conn.prepareStatement(q);
		p.setInt(1, b);
		int res = p.executeUpdate();
		if(res > 0)
		System.out.println("Deleted!");
		else
		System.out.println("Not deleted");
		}
		catch(Exception e) {System.out.println("Not deleted");}
		}
	
	void deleteRecordPes(int b) {
		String q = "DELETE FROM PatientsTable WHERE PESID = ?";
		try {
		PreparedStatement p = conn.prepareStatement(q);
		p.setInt(1, b);
		int res = p.executeUpdate();
		if(res > 0)
		System.out.println("Deleted!");
		else
		System.out.println("Not deleted");
		}
		catch(Exception e) {System.out.println("Not deleted");}
		}
	
	void displayRecords() {
		String q = "SELECT * FROM PatientsTable";
		try {
		Statement s = conn.createStatement();
		ResultSet rs = s.executeQuery(q);
		while(rs.next())
		{
		System.out.println(rs.getInt(1)+"\t\t"+rs.getString(2)+"  "+rs.getString(3)+" \t "+rs.getDate(4));
		}
		}
		catch(Exception e) {}
		}
	
	void displayRecordsPes() {
		String q = "SELECT * FROM PescriptionsTable";
		try {
		Statement s = conn.createStatement();
		ResultSet rs = s.executeQuery(q);
		while(rs.next())
		{
		System.out.println(rs.getInt(1)+"\t\t"+rs.getDate(2)+"  "+rs.getInt(3)+" \t "+rs.getString(4));
		}
		}
		catch(Exception e) {}
		}
	
	void updateRecord(int pid, String pname, String pemail, Date regdDate) {
		String q = "UPDATE PatientsTable SET PID = ?, PNAME = ?, PEMAIL = ?, PREGDDATE = ? WHERE PID = ?";
		try {
		PreparedStatement p = conn.prepareStatement(q);
		p.setInt(1, pid);
		p.setString(2,pname);
		p.setString(3,pemail);
		p.setDate(4, (java.sql.Date) regdDate);
		p.setInt(5, pid);
		int res = p.executeUpdate();
		if(res > 0)
		System.out.println("Updated!");
		else
		System.out.println("Not Updated");
		}
		catch(Exception e) {System.out.println("Not Updated");}
		}
	
	void updateRecordPes(int pesid, Date pesdate, int pid, String medname) {
		String q = "UPDATE PescriptionsTable SET PESID = ?, PESDATE = ?, PID = ?, MEDICINE = ? WHERE PESID = ?";
		try {
		PreparedStatement p = conn.prepareStatement(q);
		p.setInt(1, pesid);
		p.setDate(2, (java.sql.Date) pesdate);
		p.setInt(3,pid);
		p.setString(4, medname);
		p.setInt(5, pesid);
		int res = p.executeUpdate();
		if(res > 0)
		System.out.println("Updated!");
		else
		System.out.println("Not Updated");
		}
		catch(Exception e) {System.out.println("Not Updated");}
		}
}
 
 
 
 
 
 
 
 public class PatientsCRUD {

	 public static void main(String[] args) {
	 patientsTable pt = new patientsTable();
	 Scanner sc=new Scanner(System.in);
	 SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MMM-yyyy");
	 int choice;
	 while(true)
	 {
		 System.out.println("\nChoose\n1: REGISTER PATIENT\n2: REGISTER PRESCRIPTION\n3: UPDATE PATIENT\n4: UPDATE PRESCRIPTION\n5:"
		 		+ " DELETE PATIENT\n6: DELETE PRESCRIPTION\n7: SHOW PATIENTS\n8: SHOW PRESCRIPTIONS \n9: Exit\nEnter the choice: ");

	 choice = sc.nextInt();
	 switch(choice)
	 {
	 case 1: System.out.print("Add Record:\nEnter the PID:");
	 int pid = sc.nextInt();
	 System.out.print("Enter the Patient's Name: ");
	 String pname = sc.next();
	 System.out.print("Enter the Patient's email: ");
	 String pemail = sc.next();
	 System.out.print("Enter the date of registration: ");
	 String i = sc.next();
		Date dt=null;
		try {
			dt = dateFormat.parse(i);
		} catch (ParseException e2) {
			// TODO Auto-generated catch block
			e2.printStackTrace();
		}
	 pt.addRecord(pid, pname, pemail, dt);
	 break;
	 
	 case 2:System.out.print("Add Record:\nEnter the PESID:");
	 int pesid = sc.nextInt();
	 System.out.print("Enter the Registration Date: ");
	 String d=sc.next();
		Date dt1 = null;
		try {
			dt1 = dateFormat.parse(d);
		} catch (ParseException e2) {
			// TODO Auto-generated catch block
			e2.printStackTrace();
		}
	 
	 System.out.print("Enter the PID: ");
	 int pi = sc.nextInt();
	 System.out.print("Enter the medicine: ");
	 String med= sc.next();
	 pt.addRecordPes(pesid, dt1, pi, med);
	 break;
	 
	 case 3: System.out.print("Update Record:\nEnter the PID:");
	 int pid2 = sc.nextInt();
	 System.out.print("Enter the Patient's Name : ");
	 String pname2 = sc.next();
	 System.out.print("Enter the Patient's email: ");
	 String pemail2 = sc.next();
	 System.out.print("Enter the date of registration: ");
	 String i2 = sc.next();
		Date dt2=null;
		try {
			dt2 = dateFormat.parse(i2);
		} catch (ParseException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
	 pt.updateRecord(pid2, pname2, pemail2, dt2);
	 break;
	 
	 case 4: System.out.print("Update Record:\nEnter the PID:");
	 int pesid1 = sc.nextInt();
	 System.out.print("Enter the Registration Date: ");
	 String d1=sc.next();
		Date dt11 = null;
		try {
			dt11 = dateFormat.parse(d1);
		} catch (ParseException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
	 
	 System.out.print("Enter the PID: ");
	 int pi1 = sc.nextInt();
	 System.out.print("Enter the medicine: ");
	 String med1= sc.next();
     
	 pt.updateRecordPes(pesid1, dt11, pi1, med1);
	 break;
	 
	 case 5: System.out.println("Delete Record:\nEnter the PID");
	 int pid1 = sc.nextInt();
	 pt.deleteRecord(pid1);
	 break;
	 
	 case 6: System.out.println("Delete Record:\nEnter the PESID");
	 int pesid11 = sc.nextInt();
	 pt.deleteRecordPes(pesid11);
	 break;

	 

	 case 7: System.out.println("Patient Details:\n");
	 pt.displayRecords();
	 break;


	 case 8: System.out.println("Pescription Details:\n");
	 pt.displayRecordsPes();
	 break;


	 
	 case 9: System.out.println("Exiting!");
	 sc.close();
	 try { pt.conn.close(); }
	 catch(Exception e) {}
	 System.exit(0);

	 default: System.out.println("Invalid choice! Enter 1, 2, 3, 4,5,6,7,8, or 9!");
	 
	 }
	 }
	 }
 }

