package assessment3.demo.model;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="Pescription")
public class Pescription {
	
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "seqpes")
	@SequenceGenerator(name = "seqpes", sequenceName = "seqpes", allocationSize = 1, initialValue = 1010)
	@Column(name = "pesid")
	private int pesid;

	
	@Column(name = "PName")
	private int pname;
	
	@Column(name="medlist")
	private List<Medicine> medlist;
	
	@OneToMany(targetEntity = Medicine.class)
	private Medicine medicine;
	
	public Pescription() {
		
	}

	public Pescription(int pesid, int pname, List<Medicine> medlist, Medicine medicine) {
		super();
		this.pesid = pesid;
		this.pname = pname;
		this.medlist = medlist;
		this.medicine = medicine;
	}

	public int getPesid() {
		return pesid;
	}

	public void setPesid(int pesid) {
		this.pesid = pesid;
	}

	public int getPname() {
		return pname;
	}

	public void setPname(int pname) {
		this.pname = pname;
	}

	public List<Medicine> getMedlist() {
		return medlist;
	}

	public void setMedlist(List<Medicine> medlist) {
		this.medlist = medlist;
	}

	public Medicine getMedicine() {
		return medicine;
	}

	public void setMedicine(Medicine medicine) {
		this.medicine = medicine;
	}
	
	
	


}
