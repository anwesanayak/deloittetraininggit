package assessment3.demo.model;

import javax.persistence.Column;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

import org.hibernate.annotations.Entity;


@Entity
@Table(name="Patient")
public class Patient {

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "ins_seq")
	@SequenceGenerator(name = "ins_seq", sequenceName = "ins_seq", allocationSize = 1, initialValue = 101)
	@Column(name = "pid")
	private int pid;

	
	@Column(name = "PName", nullable = false)
	private int pname;

	@Column(name = "pemail")
	private String pemail;
	
	@OneToMany(targetEntity = Pescription.class)
	private Pescription pescription;

	public Patient() {
		
	}
	public Patient(int pid, int pname, String pemail) {
		super();
		this.pid = pid;
		this.pname = pname;
		this.pemail = pemail;
	}
	public int getPid() {
		return pid;
	}
	public void setPid(int pid) {
		this.pid = pid;
	}
	public int getPname() {
		return pname;
	}
	public void setPname(int pname) {
		this.pname = pname;
	}
	public String getPemail() {
		return pemail;
	}
	public void setPemail(String pemail) {
		this.pemail = pemail;
	}
	
	
}
