package assessment3.demo.model;

import javax.persistence.Column;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.hibernate.annotations.Entity;


@Entity
@Table(name="Medicine")
public class Medicine {

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "seq")
	@SequenceGenerator(name = "seq", sequenceName = "seq", allocationSize = 1, initialValue = 1)
	@Column(name = "mid")
	private int mid;

	
	@Column(name = "Mname", nullable = false)
	private int mname;
	
	public Medicine() {
		
	}

	public Medicine(int mid, int mname) {
		super();
		this.mid = mid;
		this.mname = mname;
	}

	public int getMid() {
		return mid;
	}

	public void setMid(int mid) {
		this.mid = mid;
	}

	public int getMname() {
		return mname;
	}

	public void setMname(int mname) {
		this.mname = mname;
	}
	
	
}
