package assessment3.demo.web;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import assessment3.demo.model.PatientDao;

/**
 * Servlet implementation class Patient
 */
@WebServlet("/Patient")
public class Patient extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private PatientDao patientdao;
       
    /**
     * @param pemail 
     * @param pname 
     * @param pid 
     * @see HttpServlet#HttpServlet()
     */
    public Patient(int pid, String pname, String pemail) {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	    String action = request.getServletPath();

        try {
            switch (action) {
                case "/insert":
                    insertUser(request, response);
                    break;
                case "/delete":
                    deleteUser(request, response);
                    break;
                case "/update":
                    updateUser(request, response);
                    break;
                default:
                    listUser(request, response);
                    break;
            }
        } catch (SQLException ex) {
            throw new ServletException(ex);
        }
       
	}
	
    private void insertUser(HttpServletRequest request, HttpServletResponse response)
    throws SQLException, IOException {
        int pid = request.getParameter("pid");
        String pname = request.getParameter("PName");
        String pemail = request.getParameter("Pemail");
        Patient patient = new Patient(pid, pname, pemail);
        patient.create(patient);
        response.sendRedirect("list");
    }
    
    private void listUser(HttpServletRequest request, HttpServletResponse response)
    throws SQLException, IOException, ServletException {
        List < Patient > listUser = patientdao.getAllUser();
        request.setAttribute("listUser", listUser);
        RequestDispatcher dispatcher = request.getRequestDispatcher("user-list.jsp");
        dispatcher.forward(request, response);
    }
    
    private void updateUser(HttpServletRequest request, HttpServletResponse response)
    throws SQLException, IOException {
        int pid = Integer.parseInt(request.getParameter("pid"));
        String pname = request.getParameter("PName");
        String pemail = request.getParameter("PEmail");

        Patient patient = new Patient(pid, pname, pemail);
        patientdao.updateUser(patient);
        response.sendRedirect("list");
    }
    private void deleteUser(HttpServletRequest request, HttpServletResponse response)
    	    throws SQLException, IOException {
    	        int id = Integer.parseInt(request.getParameter("pid"));
    	        patientdao.deleteUser(id);
    	        response.sendRedirect("list");
    	    }
    

}
